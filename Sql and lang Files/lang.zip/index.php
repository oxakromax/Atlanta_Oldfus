<?php
header("Location: http://google.com.pe");
?>